#include "log.h"
#include "format.h"
#include "mrf.h"
#include "format.h"



/** 
 *   \file mrf2bedGraph.c Module to convert MRF to BedGraph.
 *         Generates a BedGraph, where the counts are normalized by the total number of mapped reads per million. \n
 *         Usage: mrf2bedGraph <prefix> [<trackName>] \n
 *         Takes MRF from STDIN. \n
 */



typedef struct {
  char *targetName;
  int start;
  int end;
} Region;



static int sortRegionsByTargetName (Region *a, Region *b)
{
  return strcmp (a->targetName,b->targetName);
}



static void updateCounts (Array positions, int start, int end) 
{
  int i;

  for (i = start; i <= end; i++) {
    array (positions,i,int)++;
  }
}



//Create region from single MrfRead
static void processRead (Array regions, MrfRead *currRead)
{
  int i;
  MrfBlock *currBlock;
  Region *currRegion;
 
  for(i = 0; i < arrayMax (currRead->blocks); i++) {
    currBlock = arrp (currRead->blocks,i,MrfBlock);
    currRegion = arrayp (regions,arrayMax (regions),Region);
    currRegion->targetName = hlr_strdup (currBlock->targetName);
    currRegion->start = currBlock->targetStart;
    currRegion->end = currBlock->targetEnd;
  }
}



void write_bedGraphHeader( FILE *f, char* prefix, char* targetName, char* trackName) 
{
  fprintf(f, "track type=bedGraph name=%s_%s description=%s visibility=full\n", prefix, targetName, trackName ? trackName : prefix  );
}



int main (int argc, char *argv[])
{
  Stringa buffer;
  int i,j,k;
  MrfEntry *currEntry;
  Array positions;
  FILE *fp;
  Array regions;
  Region *currRegion,*nextRegion;
  int numberOfReads;
  char* trackName=NULL;

  if (argc < 2) {
    usage ("%s <prefix> [<trackName>]",argv[0]);
  }
  if( argc == 3 ) {
    trackName = hlr_strdup( argv[2] );
  }
  
  buffer = stringCreate (100);
  mrf_init ("-");
  regions = arrayCreate (10000000,Region);
  numberOfReads=0;
  while (currEntry = mrf_nextEntry ()) {
    numberOfReads++;
    processRead (regions, &currEntry->read1);
    if (currEntry->isPairedEnd) {
      numberOfReads++;
      processRead (regions,&currEntry->read2);
    }
  }
  mrf_deInit ();
  
  arraySort (regions,(ARRAYORDERF)sortRegionsByTargetName);
  positions = arrayCreate (10000000,int);
  i = 0; 
  while (i < arrayMax (regions)) {
    currRegion = arrp (regions,i,Region);
    arrayClear (positions);
    updateCounts (positions,currRegion->start,currRegion->end);
    j = i + 1;
    while (j < arrayMax (regions)) {
      nextRegion = arrp (regions,j,Region);
      if (!strEqual (currRegion->targetName,nextRegion->targetName)) {
        break;
      } 
      updateCounts (positions,nextRegion->start,nextRegion->end);
      j++;
    }
    i = j;
    stringPrintf (buffer,"%s_%s.bgr",argv[1],currRegion->targetName);
    fp = fopen (string (buffer),"w");
    if (fp == NULL) {
      die ("Unable to open file: %s",string (buffer));
    }
    write_bedGraphHeader(fp, argv[1], currRegion->targetName, trackName);
    for (k = 0; k < arrayMax (positions); k++) {
      if (arru (positions,k,int) > 0) {
	int offset=1;
	while( arru(positions, k, int) == arru(positions, k+offset, int)) {
	  offset++;
	  if( (k+offset) == arrayMax( positions ) ) { break; } // last element
	}	       
	fprintf (fp,"%s\t%d\t%d\t%.02f\n",
		 currRegion->targetName, k-1, (k-1)+offset, (double)arru (positions,k,int)/ ((double)numberOfReads / 1000000.0) );
	k=(k-1)+offset;
      }
    }
    fclose (fp);
  }
  stringDestroy (buffer);
  return 0;
}
