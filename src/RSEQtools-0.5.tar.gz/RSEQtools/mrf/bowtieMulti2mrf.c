#include "log.h"
#include "format.h"
#include "linestream.h"
#include "bowtieParser.h"
#include "numUtil.h"
#include "mrf.h"
#include <stdlib.h>
#include <time.h>



/** 
 *   \file bowtieMulti2mrf.c Module to convert Bowtie multi-reads into MRF.
 *         Assigns multi-mapping reads to a single location based on a signal track (WIG file) of uniquely mapped reads. \n
 *         Run bowtie2mrf to see command line details. \n
 *         Take bowtie output from STDIN. \n
 */



#define BIN_SIZE 100



typedef struct {
  char* chromosome;
  int position;
  double value;
} Bin;



static int sortBinsByChromosomeAndPosition (Bin *a, Bin *b)
{
  int diff;
  
  diff = strcmp (a->chromosome,b->chromosome);
  if (diff != 0) {
    return diff;
  }
  return a->position - b->position;
}



static void addBin (Array bins, char* chromosome, int position, double value)
{
  Bin *currBin;
  
  currBin = arrayp (bins,arrayMax (bins),Bin);
  currBin->chromosome = hlr_strdup (chromosome);
  currBin->position = position;
  currBin->value = value;
}



static Array processBins (char* wigPrefix)
{
  Stringa buffer;
  LineStream ls1,ls2;
  char *fileName;
  char *targetName;
  char *line,*pos;
  int j;
  int position;
  double value,binValue;
  Array bins;
   
  bins = arrayCreate (10000000,Bin);
  buffer = stringCreate (100);
  stringPrintf (buffer,"ls -1 %s*.wig",wigPrefix);
  ls1 = ls_createFromPipe (string (buffer));
  while (fileName = ls_nextLine (ls1)) {
    warn ("Processing %s ...",fileName);
    ls2 = ls_createFromFile (fileName);
    ls_nextLine (ls2); // discard track name line
    line = ls_nextLine (ls2);
    if(!strStartsWithC (line,"variableStep chrom=")) {
      die ("Expected second line to start with 'variableStep chrom=': %s",line);
    } 
    pos = strchr (line,'=');
    targetName = hlr_strdup (pos + 1);
    pos = strchr (targetName,' ');
    *pos = '\0';
    j = -1;
    binValue = 0;
    while (line = ls_nextLine (ls2)) {
      pos = strchr (line,'\t');
      *pos = '\0';
      position = atoi (line);
      value = atof (pos + 1);
      while (1) {
        j++;
        if (j == position) {
          binValue += value;
          if ((j % BIN_SIZE) == 0) {
            addBin (bins,targetName,j,binValue);
            binValue = 0;
          }
          break;
        }
        if ((j % BIN_SIZE) == 0) {
          addBin (bins,targetName,j,binValue);
          binValue = 0;
        }
      }
    }
    addBin (bins,targetName,j,binValue);
    ls_destroy (ls2);
  }
  ls_destroy (ls1);
  // Note that the bins are already sorted by chromosome and position
  return bins;
}



int main (int argc, char *argv[])
{
  int includeSequences,includeQualityScores;
  Array bins;
  BowtieQuery *currBQ;
  BowtieEntry *currBE;
  Bin *currBin,testBin;
  int index;
  int i,j;
  Array values;
  Array indices;
  double totalValues;
  int num;
  int readLength;
  double weightedBinValue;
  int overlap;
  int sequenceLength;

  if (argc < 2) {
    usage ("%s <wigPrefix> -sequence -qualityScores",argv[0]);
  }
  includeSequences = 0;
  includeQualityScores = 0;
  i = 2;
  while (i < argc) {
    if (strEqual (argv[i],"-sequence")) {
      includeSequences = 1;
    }
    if (strEqual (argv[i],"-qualityScores")) {
      includeQualityScores = 1; 
    }
    i++;
  }
  printf ("%s",MRF_COLUMN_NAME_BLOCKS);
  if (includeSequences == 1) {
    printf ("\t%s",MRF_COLUMN_NAME_SEQUENCE);
  }
  if (includeQualityScores == 1) {
    printf ("\t%s",MRF_COLUMN_NAME_QUALITY_SCORES);
  }
  puts ("");

  bins = processBins (argv[1]);
  srand (time (0));
  values = arrayCreate (100,double);
  indices = arrayCreate (100,int);
  bowtieParser_initFromFile ("-");
  while (currBQ = bowtieParser_nextQuery ()) {
    if (arrayMax (currBQ->entries) == 1) {
      continue;
    }
    totalValues = 0.0;
    arrayClear (indices);
    arrayClear (values);
    for (i = 0; i < arrayMax (currBQ->entries); i++) {
      currBE = arrp (currBQ->entries,i,BowtieEntry);
      if (i == 0) {
        readLength = strlen (currBE->sequence);
      }
      testBin.position = currBE->position;
      testBin.chromosome = hlr_strdup (currBE->chromosome);
      arrayFind (bins,&testBin,&index,(ARRAYORDERF)sortBinsByChromosomeAndPosition);
      weightedBinValue = 0.0;
      j = index + 1;
      while (j < (arrayMax (bins) - 1)) {
        currBin = arrp (bins,j,Bin);
        overlap = rangeIntersection (currBE->position,currBE->position + readLength,currBin->position - BIN_SIZE,currBin->position);
        weightedBinValue +=  ((double)overlap / readLength) * currBin->value;
        if ((currBE->position + readLength) < currBin->position) {
          break;
        }
        j++;
      }
      totalValues += weightedBinValue; 
      array (values,arrayMax (values),double) = weightedBinValue;
      hlr_free (testBin.chromosome);
    }
    if (totalValues > 0) {
      for (i = 0; i < arrayMax (values); i++) {
        num = (int)(100 * arru (values,i,double) / totalValues);
        for (j = 0; j < num; j++) {
          array (indices,arrayMax (indices),int) = i;
        }
      }
      currBE = arrp (currBQ->entries,arru (indices,rand () % arrayMax (indices),int),BowtieEntry); 
      sequenceLength = (int)strlen (currBE->sequence);
      printf ("%s:%c:%d:%d:%d:%d\n",
              currBE->chromosome,
              currBE->strand,
              currBE->position,
              currBE->position + sequenceLength - 1,
              1,
              sequenceLength);
    }
  }
  bowtieParser_deInit ();
  return 0;
}
